# Birds of a feather

## Project Description
Helping Secondary School Students become the next generation of tech leaders.
Gain access to Secondary School students by maintaining a registy of pre-approved (recognised by MOE) volunteers.
Provide a website to facilitate coordination between GovTech, MOE, community builders and volunteers.

Live website: https://bof-585042202600.us-central1.run.app/

## Link to Presentation

https://docs.google.com/presentation/d/1PtoXVJVSmRBs-1MT3G0HUr7Tg07Q_YXKm96W0anXWFo/edit?usp=sharing

## Repository URL

https://github.com/siuyin/birds-of-a-feather
