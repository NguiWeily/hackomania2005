package public

import "embed"

//go:embed *
var Content embed.FS
