# This folder contains the main Birds of a Feather website


1) Public
 a) Guest - I see confirmed events and proposed events when I open an event I can see event details and attend button.
 b) Reg - To attend or show interest - you have to register. Role of this type of uSERs Reg 
 
2) Event ideator Page - List of contacts, 
           Form to create Event
           Status - Proposed/ waiting something
           Move to MOE Facilitator board
3) MOE Facilitator Page - List of Schools/Ministry contacts.
           Talk to schools and moe and get approvals
            Status -  waiting approval
           Move to Logistics board.
4) Logistics Page - List of Sponsors/Venue contacts.
          Talk to sponsors/ venue people and conifrm sponsors and venue and 
           Status -  waiting for what 
          Move to admin.
5) Admin -  approve events and publishes events, event promotions/adverstisements